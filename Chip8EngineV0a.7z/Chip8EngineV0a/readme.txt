This application was not created for the public. I do not plan on updating, fixing, debugging or
any kind of modifyications of "chip8_engine". Run at your own risk

- Jonathan M Duggan